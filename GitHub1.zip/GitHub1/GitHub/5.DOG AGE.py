n=int(input())
print(n*7)